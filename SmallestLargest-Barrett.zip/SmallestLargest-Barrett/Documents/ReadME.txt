Clark Barrett
Jan 17 2023
CS 335-01 Barbara Chamberlin
Assignment 2.2 "Smallest and Largest"
Description: Application creates an array with given integers and finds the smallest and largest values.  Also saves the difference between the two as a highscore.
I pledge that the work done here was my own and that I have learned how to write this program, such that I could throw it out and restart and finish it in a timely manner. I am not turning in any work that I cannot understand, describe, or recreate. I further acknowledge that I contributed substantially to all code handed in and vouch for its authenticity. 
-Clark Barrett